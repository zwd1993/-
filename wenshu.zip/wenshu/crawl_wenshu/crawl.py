# -*- coding: utf-8 -*-
import execjs
import json
import re
import math
from utils.wenshu_log import getLogger
from utils.wenshu_session import getSess
from utils.yundama import result_captcha
import time
from utils.captcha_local import retrive_img,process_img,recognize
import random
from scrapy.selector import Selector
import requests
import os


sess,vl5x = getSess()

logger = getLogger(__name__)


headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0',
    'X-Forwarded-For': '{}.{}.{}.{},113.88.176.160'.format(random.randint(1,254),random.randint(1,254),random.randint(1,254),random.randint(1,254))
}

with open('ua_list.json', 'r') as f:
    ua_list = json.load(f)

def crwal_condition(condition,total, target):
    '''
    :param condition: 查询的条件
    :param total: 所有的案由
    :return:
    '''
    anyou = '  '.join(total)
    count,id_list = getFirstPage(condition,total)

    if count=='':
        return
    # count为0时 id_list = []
    if count==0:
        print 'crawl %s over' % (condition)
        return
    elif count<=20:
        for docID in id_list:
            insertMysql(docID,anyou,count)

        print 'crawl %s over' % (condition)
        return

    # elif count>2000:
    #     cursor.execute('''insert into wenshu(anyou, count) VALUES (%s,%s)''',
    #                    (anyou, count))
    #     conn.commit()
    #     print (anyou + ', count is: %s' % (count))
    #     print 'crawl %s over' % (condition)
    #     return

    else:
        index = int(math.ceil(count/20.0))
        for docID in id_list:
            insertMysql(docID, anyou, count)
        page=2
        while page <=index:
            count, id_list = getFirstPage(condition,total,index=page)
            if id_list=='':
                return
            for docID in id_list:
                insertMysql(docID, anyou, count)
            page+=1
    print 'crawl %s over' %(condition)
    return

def getCaptcha():
    global sess,vl5x
    ua = random.choice(ua_list)
    while True:
        try:
            yzm = execjs.compile('''
            function createGuid() {
                return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
            }
            function ref() {
                var guid = createGuid() + createGuid() + "-" + createGuid() + "-" + createGuid() + createGuid() + "-" + createGuid() + createGuid() + createGuid(); //CreateGuid();
                return guid;
            }
            ''')
            guid = yzm.call('ref')
            yzm_url = "http://wenshu.court.gov.cn/ValiCode/GetCode"
            headers = {
                'User-Agent': ua,
                'X-Forwarded-For': '{}.{}.{}.{},113.88.176.160'.format(random.randint(1, 254), random.randint(1, 254),
                                                                       random.randint(1, 254), random.randint(1, 254))
            }

            yzm = sess.post(yzm_url, headers = headers, allow_redirects = False, data = {"guid": guid})
            if yzm.status_code == 302:
                sess, vl5x = getSess()
                continue
            if yzm.status_code >= 500:
                print 'the service is bad and response_status_code is %s, wait one minute retry' % (
                    yzm.status_code)
                time.sleep(60)
                continue
            

            return yzm.content, guid
        except Exception as e:
            print 'get captcah bad retry again'
            pass


def getFirstPage(condition,total,index=1):
    '''
    :param condition:
    :param total:
    :param index:
    :return:
    '''
    global sess, vl5x
    anyou = ','.join(total)
    num_level = 0
    level = condition[0:4]

    #if u'一级案由' == level:
    #    num_level = 1
    #elif u'二级案由' == level:
    #    num_level = 2
    #elif u'三级案由' == level:
    #    num_level = 3
    #elif u'四级案由' == level:
     #   num_level = 4
    num_level = 0
    i = 0
    while i < 5:
        captcha, guid = getCaptcha()
        print "captcha {}, guid {}".format(captcha, guid)
        form_data = {
            'Param': condition,
            'Index': index,
            'Page': 20,
            'Order': '法院层级',
            'Direction': 'asc',
            'vl5x': vl5x,
            'number': captcha,
            'guid': guid,

        }
        try:
            ua = random.choice(ua_list)
            headers = {
                'User-Agent': ua,
                'X-Forwarded-For': '{}.{}.{}.{},113.88.176.160'.format(random.randint(1, 254), random.randint(1, 254),
                                                                       random.randint(1, 254), random.randint(1, 254))
            }
            print num_level*'    '+'%s is crawling index is %s' %(condition, index)
            response = sess.post('http://wenshu.court.gov.cn/List/ListContent', headers=headers, data=form_data)
            if response.status_code == 302:
                sess, vl5x = getSess()
                continue
            if response.status_code >= 500:
                print 'the service is bad and response_status_code is %s, wait one minute retry' % (
                    response.status_code)
                time.sleep(60)
                continue
            data_unicode = json.loads(response.text)

            if data_unicode == u'remind key':
                sess, vl5x = getSess()
                print 'getFirstPage response content is remind key retry again'
                continue
            if data_unicode == u'remind':
                sess, vl5x = getSess()
                ua = random.choice(ua_list)
                remind_captcha = sess.get('http://wenshu.court.gov.cn/User/ValidateCode',headers=headers)
                img = retrive_img(remind_captcha)
                img = process_img(img)
                captcha = recognize(img)
                captcha_data = {
                    'ValidateCode': captcha
                }

                sess.post('http://wenshu.court.gov.cn/Content/CheckVisitCode',headers=headers,data=captcha_data)
                print 'getFirstPage response content is remind  retry again %s ' % captcha
                continue
            id_list = re.findall(u'''.*?"文书ID\\":\\"(.*?)\\",''', data_unicode)

            data_list = json.loads(data_unicode)
            if len(data_list) == 0:
                time.sleep(2)
                print 'getFirstPage response content is [] retry again'
                continue
            count = data_list[0]['Count']
            count = int(count)
            return count,id_list
        except Exception as e:
            i += 1
            if i == 5:
                message = anyou+': '+str(index)+str(e).decode('utf-8')+'   '+'is bad'
                logger.error(message)
                print (message)
                return '',''


def insertMysql(docID,anyou,count):
    '''

    :param docID: 文书ID
    :param anyou: 案由条件
    :param count: 案由条件对应的文档个数
    :return:
    '''
    global sess, vl5x
    doc_url = 'http://wenshu.court.gov.cn/CreateContentJS/CreateContentJS.aspx?DocID={}'.format(docID)
    i = 0
    while True:
        try:
            ua = random.choice(ua_list)
            headers = {
                'User-Agent': ua,
                'X-Forwarded-For': '{}.{}.{}.{},113.88.176.160'.format(random.randint(1, 254), random.randint(1, 254),
                                                                       random.randint(1, 254), random.randint(1, 254))
            }
            doc_response = sess.get(doc_url, headers=headers)

            if doc_response.status_code == 302:
                sess, vl5x = getSess()
                continue
            if doc_response.status_code >= 500:
                print 'the service is bad and response_status_code is %s, wait one minute retry' % (
                    doc_response.status_code)
                time.sleep(60)
                continue
            try:
                data_unicode = json.loads(doc_response.text)
                if data_unicode == u'remind key':
 
                    sess, vl5x = getSess()
                    print 'getFirstPage response content is remind key retry again'
                    continue
                if data_unicode == u'remind':
 
                    sess, vl5x = getSess()
                    ua = random.choice(ua_list)
                    remind_captcha = sess.get('http://wenshu.court.gov.cn/User/ValidateCode', headers=headers)
                    img = retrive_img(remind_captcha)
                    img = process_img(img)
                    captcha = recognize(img)
                    captcha_data = {
                        'ValidateCode': captcha
                    }
                    sess.post('http://wenshu.court.gov.cn/Content/CheckVisitCode', headers=headers, data=captcha_data)
                    print 'getFirstPage response content is remind  retry again'
                    continue
            except Exception as e:
                pass
 
            title = re.search(u'''.*?"Title(.*?)PubDate''', doc_response.content).group(1)
            pubDate = re.search(u'''.*?PubDate(.*?)Html''', doc_response.content).group(1)
            title = re.match(r'\\":\\"(.*?)\\",\\"', title).group(1).decode('utf-8')
            pubDate = re.match(r'\\":\\"(.*?)\\",\\"', pubDate).group(1)
            select = Selector(doc_response)
            doc_list = select.xpath("//div//text()").extract()
            content = '  '.join(doc_list)
            doc = u'标题:' + title + u',发布日期:' + pubDate + u',正文:' + content

            print doc
            
            create_dir = ""


            if len(target) != 0:
                create_dir = "%s/%s" % (target, pubDate)
            else:
                create_dir = "%s" % pubDate


            if not os.path.exists(create_dir):
                os.makedirs(create_dir)

            try:
                txt = "%s/%s.txt" % (create_dir, title)
                print txt
            except e:
                print e

            with open(txt, "w") as f:
                f.write(content.encode("utf-8"))
                f.close()
                
            time.sleep(5)
            break
        except Exception as e:
            time.sleep(2)
            i+=1
            if i==5:
                message = anyou + ': ' + str(docID) + str(e).decode('utf-8') + '   ' + 'is bad'
                logger.error(message)
                print (message)
                break
            continue

def setup():
    print u"输入检索条件,如： '三级案由:知识产权合同纠纷,法院地域:北京市'"
    key = raw_input().decode('gbk')
    print u"输入数据存放位置，车选取当前目录:"
    target = raw_input()

    if key is None:
        print u"请输入关键字"
    return key, target
    
    
if __name__ == '__main__':
#    condition = u"四级案由: 专利权权属、侵权纠纷"
    #condition = u'三级案由:知识产权合同纠纷,法院地域:北京市'
    #condition = u"三级案由: 知识产权合同纠纷"
    #crwal_condition(u'三级案由:爆炸',[])
    #crwal_condition(condition,[])

    key, target = setup()

    crwal_condition(key, [], target)
    

